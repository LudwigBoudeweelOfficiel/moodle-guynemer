document.getElementById("loginForm").addEventListener("submit", function(event) {
  event.preventDefault(); // Empêche la soumission du formulaire par défaut

  // Récupérer les valeurs du formulaire
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;

  // Créer l'objet XMLHttpRequest pour envoyer la requête
  var xhr = new XMLHttpRequest();

  // Gérer la réponse de la requête
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4) { // La requête est terminée
      if (xhr.status === 200) { // La requête a réussi
        var response = JSON.parse(xhr.responseText);
        if (response.success) {
          // Rediriger vers la page home.php en cas de succès
		  document.getElementById("username").style.border = "2px solid #90C884";
		  document.getElementById("password").style.border = "2px solid #90C884";
		  document.getElementById("username").style.backgroundColor = "#B5E6AA";
		  document.getElementById("password").style.backgroundColor = "#B5E6AA";
		  
		  var element = document.getElementById("loginForm");
		  element.classList.add("slide-in"); // Ajoute la classe "slide-in" à l'élément
		  
		  var pwd1 = document.getElementById("pwd_correct");
		  pwd1.classList.add("on_pwdcorrect"); // Ajoute la classe "slide-in" à l'élément
		  
		  setTimeout(function() {
		  window.location.href = "fil.php"; // Remplacez l'URL par l'adresse de destination souhaitée
		  }, 1000); // 3000 millisecondes = 3 secondes

		  
          // window.location.href = "home.php";
        } else {
          // Rediriger vers la page d'authentification en cas d'échec
          window.location.href = "login1.php";
        }
      } else {
        // Gérer les erreurs de la requête
        console.error("Erreur de la requête : " + xhr.status);
      }
    }
  };

  // Envoyer la requête POST avec les données du formulaire
  xhr.open("POST", "verification.php", true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.send("username=" + encodeURIComponent(username) + "&password=" + encodeURIComponent(password));
});