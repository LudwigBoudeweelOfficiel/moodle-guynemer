<html>
	<head>
		<title>Moodle GUYNEMER</title>
		<link href="css/style.css" rel="stylesheet"/>
	</head>

	<body>
		<section class="s_login">
			<h1 id="title"><?php include('prm/parametres.php'); echo $title_homepagesite ?></h1>
			
			<h3 id="pwd_correct">Mot de passe correct</h3>
			
			<form id="loginForm">
				<input type="text" id="username" name="username" placeholder="UName"/>
				<input type="password" id="password" name="password" placeholder="Mot de passe"/>
				</br></br>
				<input type="submit" value="Enregistrer">
			</form>
						
			<script src="scripts/script.js"></script>
		</section>
	</body>
</html>