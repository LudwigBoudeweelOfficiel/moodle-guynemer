<?php

// Récupérer les valeurs du formulaire
$username = $_POST['username'];
$password = $_POST['password'];


// Supposons que les identifiants et les mots de passe corrects soient "admin" et "password"
$correctUsername = "admin";
$correctPassword = "guynemer";

if ($username === $correctUsername && $password === $correctPassword) {
  // Authentification réussie
  $response = array('success' => true);
} else {
  // Authentification échouée
  $response = array('success' => false);
}

// Renvoyer la réponse au format JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
	